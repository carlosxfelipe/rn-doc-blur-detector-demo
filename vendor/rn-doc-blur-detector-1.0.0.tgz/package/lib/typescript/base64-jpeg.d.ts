import { type BlurAnalysisResult, type LaplacianBlurConfig, type RgbaImageBuffer } from "./laplacian-blur-detector";
/**
 * Decodes a base64 string (or data URI) into a Uint8Array without Node `Buffer`.
 */
export declare function base64ToUint8Array(input: string): Uint8Array;
/**
 * Encodes a Uint8Array into a standard base64 string without Node `Buffer`.
 */
export declare function uint8ArrayToBase64(bytes: Uint8Array): string;
/**
 * Checks whether a byte buffer starts with a valid JPEG SOI marker (0xFF 0xD8).
 */
export declare function isJpegBytes(bytes: Uint8Array): boolean;
/**
 * Decodes raw JPEG bytes into an RGBA pixel buffer using pure JS (`jpeg-js`).
 */
export declare function decodeJpegBytesToRgba(bytes: Uint8Array): RgbaImageBuffer;
/**
 * Decodes a JPEG base64 payload (or data URI) into an RGBA pixel buffer using pure JS.
 */
export declare function decodeJpegBase64ToRgba(base64: string): RgbaImageBuffer;
/**
 * Decodes raw JPEG bytes and runs Global Laplacian blur analysis.
 */
export declare function analyzeJpegBytesBlur(bytes: Uint8Array, config?: Partial<LaplacianBlurConfig>): BlurAnalysisResult;
/**
 * Decodes a JPEG base64 payload (or data URI) and runs Global Laplacian blur analysis.
 */
export declare function analyzeJpegBase64Blur(base64: string, config?: Partial<LaplacianBlurConfig>): BlurAnalysisResult;
//# sourceMappingURL=base64-jpeg.d.ts.map