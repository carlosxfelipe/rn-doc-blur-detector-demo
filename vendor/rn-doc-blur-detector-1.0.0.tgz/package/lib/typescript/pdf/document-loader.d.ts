import type { ExtractedDocumentPage, ExtractedPdfResult, ImageExtractOptions, ImageSourceInput, PdfExtractOptions, PdfSourceInput } from "./types";
/**
 * Extracts RGBA pixels from an image using browser Canvas when in a DOM
 * environment, or the React Native JPEG decoder otherwise.
 */
export declare function extractImagePage(source: ImageSourceInput, maxDimOrOptions?: number | ImageExtractOptions): Promise<ExtractedDocumentPage>;
/**
 * Extracts rendered PDF pages using PDF.js directly in a browser DOM, or the
 * React Native WebView bridge otherwise.
 */
export declare function extractPdfPages(source: PdfSourceInput, options?: PdfExtractOptions): Promise<ExtractedPdfResult>;
/**
 * Reads a URI as a raw base64 string using the runtime-appropriate loader.
 */
export declare function readUriAsBase64(uri: string): Promise<string>;
/**
 * Reads a URI into raw bytes using the runtime-appropriate loader.
 */
export declare function readUriAsBytes(uri: string): Promise<Uint8Array>;
//# sourceMappingURL=document-loader.d.ts.map