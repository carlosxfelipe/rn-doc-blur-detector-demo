import type { ExtractedDocumentPage, ExtractedPdfResult, ImageExtractOptions, ImageSourceInput, PdfExtractOptions, PdfSourceInput } from "./types";
export declare function readUriAsBytes(uri: string): Promise<Uint8Array>;
export declare function readUriAsBase64(uri: string): Promise<string>;
/**
 * Decodes an image URI or base64 payload via browser HTMLCanvasElement into RGBA pixels.
 */
export declare function extractImagePage(source: ImageSourceInput, maxDimOrOptions?: number | ImageExtractOptions): Promise<ExtractedDocumentPage>;
/**
 * Renders PDF pages on Web via PDF.js CDN into RGBA buffers + preview data URLs.
 */
export declare function extractPdfPages(source: PdfSourceInput, options?: PdfExtractOptions): Promise<ExtractedPdfResult>;
//# sourceMappingURL=document-loader.web.d.ts.map