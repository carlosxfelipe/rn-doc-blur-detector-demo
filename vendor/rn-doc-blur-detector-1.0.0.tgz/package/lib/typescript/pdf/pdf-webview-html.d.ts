/**
 * WebView HTML document that uses PDF.js (via jsDelivr CDN) for Web/fallback
 * environments. iOS and Android resolve `pdf-webview-html.native` (vendored offline).
 */
export declare const PDF_WEBVIEW_HTML: string;
//# sourceMappingURL=pdf-webview-html.d.ts.map