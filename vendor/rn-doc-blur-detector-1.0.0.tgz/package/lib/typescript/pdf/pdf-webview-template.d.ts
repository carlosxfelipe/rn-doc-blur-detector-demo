/**
 * Shared HTML template for the hidden WebView that renders PDF pages using PDF.js.
 */
export declare function buildPdfWebViewHtml(getPdfJsSnippet: string): string;
//# sourceMappingURL=pdf-webview-template.d.ts.map