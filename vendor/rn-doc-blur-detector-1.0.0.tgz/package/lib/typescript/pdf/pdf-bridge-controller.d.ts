import type { PdfBridgeJobParams, PdfBridgePagePayload, PdfBridgeResult } from "./types";
export type PdfBridgeIncomingMessage = {
    type: "ready";
} | {
    type: "progress";
    requestId: string;
    current: number;
    total: number;
} | ({
    type: "page";
    requestId: string;
} & PdfBridgePagePayload) | {
    type: "done";
    requestId: string;
    totalPages: number;
    processedPages: number;
    truncated: boolean;
} | {
    type: "error";
    requestId: string;
    message: string;
};
export interface PdfBridgeController {
    /** Returns whether the WebView has posted its `{ type: "ready" }` handshake. */
    isReady: () => boolean;
    /** Feed `event.nativeEvent.data` from `WebView.onMessage` into this handler. */
    handleMessage: (rawData: string) => void;
    /** Runs a PDF rasterization job using a `WebView.injectJavaScript` callback. */
    runJob: (params: PdfBridgeJobParams, injectJavaScript: (script: string) => void) => Promise<PdfBridgeResult>;
    /** Cancels the currently active PDF job, if any. */
    cancel: (reason?: string) => void;
    /** Resets readiness state and rejects any waiting/pending promises. */
    reset: () => void;
}
/**
 * Pure TypeScript state machine for communicating with the hidden PDF.js WebView
 * (`PDF_WEBVIEW_HTML`), without requiring `.tsx` or `react-native-webview` inside this package.
 */
export declare function createPdfBridgeController(options?: {
    readyTimeoutMs?: number;
    jobTimeoutMs?: number;
}): PdfBridgeController;
//# sourceMappingURL=pdf-bridge-controller.d.ts.map