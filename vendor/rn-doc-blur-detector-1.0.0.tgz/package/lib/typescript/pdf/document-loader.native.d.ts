import type { ExtractedDocumentPage, ExtractedPdfResult, ImageExtractOptions, ImageSourceInput, PdfExtractOptions, PdfSourceInput } from "./types";
/**
 * Reads a `file://`, `content://`, `http(s)://`, or `data:` URI into raw bytes
 * using standard React Native `fetch` (no Expo or native FS module required).
 */
export declare function readUriAsBytes(uri: string): Promise<Uint8Array>;
/**
 * Reads a `file://`, `content://`, `http(s)://`, or `data:` URI as a raw base64 string
 * using standard React Native `fetch` + `FileReader`.
 */
export declare function readUriAsBase64(uri: string): Promise<string>;
/**
 * Extracts RGBA pixels from an image on React Native (Expo or Bare RN).
 */
export declare function extractImagePage(source: ImageSourceInput, maxDimOrOptions?: number | ImageExtractOptions): Promise<ExtractedDocumentPage>;
/**
 * Extracts rendered PDF pages on iOS/Android via a WebView PDF.js bridge (`renderPdfViaBridge`),
 * then decodes each page into RGBA pixels in TypeScript for Laplacian analysis.
 */
export declare function extractPdfPages(source: PdfSourceInput, options?: PdfExtractOptions): Promise<ExtractedPdfResult>;
//# sourceMappingURL=document-loader.native.d.ts.map