import { type BlurAnalysisResult, type DocumentSummaryResult, type LaplacianBlurConfig } from "../laplacian-blur-detector";
import type { AnalyzedDocumentItem, ExtractedDocumentPage, ImageExtractOptions, ImageSourceInput, PdfExtractOptions, PdfSourceInput } from "./types";
export declare const DEFAULT_MAX_FILE_SIZE_MB = 9;
export declare const DEFAULT_MAX_FILE_SIZE_BYTES: number;
export declare function formatBytes(bytes?: number): string;
export declare function isPdfAsset(name: string, mimeType?: string): boolean;
export declare function isImageAsset(name: string, mimeType?: string): boolean;
export interface FileSizeValidationResult {
    valid: boolean;
    sizeBytes?: number;
    maxBytes: number;
    formattedSize: string;
}
export declare function validateFileSize(sizeBytes?: number, maxSizeMb?: number): FileSizeValidationResult;
/**
 * Runs Global Laplacian analysis on extracted pages and assembles an `AnalyzedDocumentItem`.
 */
export declare function buildAnalyzedDocument(item: Omit<AnalyzedDocumentItem, "pageAnalyses" | "summary">, config?: Partial<LaplacianBlurConfig>): AnalyzedDocumentItem;
export interface AnalyzeImageOptions extends ImageExtractOptions {
    config?: Partial<LaplacianBlurConfig>;
}
export interface AnalyzeImageResult {
    page: ExtractedDocumentPage;
    analysis: BlurAnalysisResult;
}
export interface AnalyzePdfOptions extends PdfExtractOptions {
    config?: Partial<LaplacianBlurConfig>;
}
export interface AnalyzePdfResult {
    totalPages: number;
    processedPages: number;
    truncated: boolean;
    pages: ExtractedDocumentPage[];
    pageAnalyses: BlurAnalysisResult[];
    summary: DocumentSummaryResult;
}
/**
 * High-level helper that extracts RGBA pixels from an image and runs Laplacian blur analysis.
 */
export declare function analyzeImage(source: ImageSourceInput, options?: AnalyzeImageOptions): Promise<AnalyzeImageResult>;
/**
 * High-level helper that rasterizes PDF pages and runs per-page + aggregated blur analysis.
 */
export declare function analyzePdf(source: PdfSourceInput, options?: AnalyzePdfOptions): Promise<AnalyzePdfResult>;
//# sourceMappingURL=analyze-document.d.ts.map