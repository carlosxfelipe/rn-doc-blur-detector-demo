/**
 * Hidden WebView HTML document that uses vendored PDF.js (offline, via Blob URLs)
 * to render PDF pages to high-quality JPEG frames on iOS and Android without network
 * or native PDF libs.
 */
export declare const PDF_WEBVIEW_HTML: string;
//# sourceMappingURL=pdf-webview-html.native.d.ts.map