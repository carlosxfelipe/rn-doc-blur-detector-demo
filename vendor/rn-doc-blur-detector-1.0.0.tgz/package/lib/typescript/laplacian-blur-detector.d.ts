/**
 * Pure TypeScript Document Blur Detector using Global Laplacian Variance.
 *
 * Zero React, Expo, React Native, or DOM dependencies — works in Expo,
 * bare React Native, Web, and Node.js.
 */
export interface RgbaImageBuffer {
    width: number;
    height: number;
    data: Uint8Array | Uint8ClampedArray;
}
export type BlurStatus = "sharp" | "borderline" | "blurry" | "insufficient";
export type BlurLocale = "pt-BR" | "en";
export interface BlurAnalysisMessages {
    insufficientLabel: string;
    insufficientReason: string;
    blurryLabel: string;
    blurryReason: string;
    borderlineLabel: string;
    borderlineReason: string;
    sharpLabel: string;
    sharpReason: string;
    summaryNoPagesLabel: string;
    summaryBlurrySingleLabel: string;
    summaryBlurryMultiPrefix: string;
    summaryBorderlineSingleLabel: string;
    summaryBorderlineMultiPrefix: string;
    summaryPagePrefix: string;
}
export interface LaplacianBlurConfig {
    maxAnalysisDim: number;
    sharpScoreThreshold: number;
    blurScoreThreshold: number;
    laplacianRef: number;
    globalRefFactor: number;
    minContentContrast: number;
    minContentStdDev: number;
    locale?: BlurLocale;
    messages?: Partial<BlurAnalysisMessages>;
}
export interface BlurAnalysisMetrics {
    globalLaplacianVar: number;
    analyzedWidth: number;
    analyzedHeight: number;
    elapsedMs: number;
}
export interface BlurAnalysisResult {
    status: BlurStatus;
    label: string;
    reason: string;
    score: number;
    metrics: BlurAnalysisMetrics;
}
export interface DocumentSummaryResult {
    status: BlurStatus;
    label: string;
    score: number;
    affectedPages: number[];
}
export declare const BLUR_MESSAGES_BY_LOCALE: Record<BlurLocale, BlurAnalysisMessages>;
export declare const DEFAULT_LAPLACIAN_CONFIG: LaplacianBlurConfig;
/**
 * Downsamples an RGBA buffer with box averaging when its longest edge exceeds `maxDim`.
 */
export declare function resizeRgbaIfNeeded(image: RgbaImageBuffer, maxDim: number): RgbaImageBuffer;
/**
 * Converts RGBA pixels to grayscale luminance (0..255), compositing alpha over white paper.
 */
export declare function toGrayscaleLuminance(data: Uint8Array | Uint8ClampedArray, width: number, height: number): {
    lum: Float32Array;
    contrast: number;
    stdDev: number;
};
/**
 * Computes sharpness directly from a grayscale luminance buffer (`0..255` per pixel),
 * avoiding RGBA conversion overhead (e.g. Y-plane from camera frame processors).
 */
export declare function analyzeLuminanceBlur(lum: ArrayLike<number>, width: number, height: number, userConfig?: Partial<LaplacianBlurConfig>): BlurAnalysisResult;
/**
 * Computes sharpness using Global Classic Laplacian Variance (4-neighbor kernel).
 */
export declare function analyzeGlobalLaplacianBlur(image: RgbaImageBuffer, userConfig?: Partial<LaplacianBlurConfig>): BlurAnalysisResult;
/**
 * Aggregates per-page blur results into an overall document verdict.
 */
export declare function aggregateDocumentResults(pageResults: readonly BlurAnalysisResult[], options?: {
    locale?: BlurLocale;
    messages?: Partial<BlurAnalysisMessages>;
}): DocumentSummaryResult;
//# sourceMappingURL=laplacian-blur-detector.d.ts.map